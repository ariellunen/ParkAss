export default {
  'Tel Aviv-Yafo': '0542344828',
  'Ramat Gan': '0545693030',
};
