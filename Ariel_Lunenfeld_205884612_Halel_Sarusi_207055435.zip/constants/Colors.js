export default {
  primary: '#C2185B',
  accent: '#FFC107',
};
