const vars = {
  googleApiKey: 'AIzaSyANv-6zqK0wzXkwJa2iwQJOXkdGT8IDMec',
};
export default vars;
